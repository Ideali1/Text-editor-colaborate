package TextEditori;



import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.SwingWorker;
import javax.swing.GroupLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultCaret;

import client.Client;



public class DocumentView extends JPanel {

	private static final long serialVersionUID = 1L;
	private JFrame frame;
	private JMenuBar menu;
	private JMenu file, edit;
	private JMenuItem newfile, open, exit, copy, cut, paste, save; 
	private JLabel documentNameLabel;
	private String documentName, documentText;
	private JTextArea area;
	private JScrollPane scrollpane;
	private DefaultCaret caret;
	private TextDocumentListener documentListener;
	private final Client client;
	private final String username;
	private int currentVersion;
	private boolean sent = false; 
	
	
	public DocumentView(MainWindow frame) {
		this.frame = frame;
		this.client = null;
		this.username = "";
		documentNameLabel = new JLabel("You are editing document: ");
		createLayout();
	}


	public DocumentView(MainWindow frame, String documentName, String text) {

		this.frame = frame;
		this.client = frame.getClient();
		this.documentName = documentName;
		this.username = frame.getUsername();
		documentText = KodimiDekodimi.decode(text);
		documentNameLabel = new JLabel("<html><B>"+documentName+"</B></html>");
		createLayout();
	}

	
	private void createLayout() {
		
		menu = new JMenuBar();
		file = new JMenu("Fajll");
		edit = new JMenu("Edito");
		menu.add(file);
		menu.add(edit);

		newfile = new JMenuItem("I Ri");
		newfile.addActionListener(new NewFileListener());
		file.add(newfile);
		
		copy = new JMenuItem("Copy");
		copy.addActionListener(new CopyListener());
		edit.add(copy);
		
		cut = new JMenuItem("Cut");
		cut.addActionListener(new CutListener());
		edit.add(cut);
		
		paste = new JMenuItem("Paste");
		paste.addActionListener(new PasteListener());
		edit.add(paste);

		open = new JMenuItem("Hap");
		open.addActionListener(new OpenFileListener());
		file.add(open);
                
                save = new JMenuItem("Ruaj");
		open.addActionListener(new SaveFileListener());
		file.add(save);

		exit = new JMenuItem("Mbyll");
		exit.addActionListener(new ExitFileListener());
		file.add(exit);
		frame.setJMenuBar(menu);
		
		caret = new DefaultCaret();
		area = new JTextArea(25, 65);
		area.setLineWrap(true);
		area.setText(documentText);
		area.setWrapStyleWord(true);
		
		
		area.setCaret(caret);
		documentListener = new TextDocumentListener();
		area.getDocument().addDocumentListener(documentListener); 
		
		scrollpane = new JScrollPane(area);
		scrollpane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

		GroupLayout layout = new GroupLayout(this);
		setLayout(layout);
		layout.setAutoCreateGaps(true);
		layout.setAutoCreateContainerGaps(true);

		layout.setHorizontalGroup(layout.createParallelGroup()
				.addComponent(documentNameLabel)
				.addComponent(scrollpane));
		layout.setVerticalGroup(layout.createSequentialGroup()
				.addComponent(documentNameLabel)
				.addComponent(scrollpane));
	}


	
	private class TextDocumentListener implements DocumentListener {
	
		public void insertUpdate(DocumentEvent e) {
			synchronized (area) {
				int changeLength = e.getLength();
				int offset = e.getOffset();
				int insert = caret.getDot();
				String message;
				try {
					String addedText = area.getDocument().getText(offset,
							changeLength);
					String encodedText = KodimiDekodimi.encode(addedText);					
					currentVersion=client.getVersion();
					message = "change " + documentName + " "+username+" "+ currentVersion+ " insert " + encodedText
							+ " " + insert;
					
					sent = true;
	            	MessageSwingWorker worker = new MessageSwingWorker(client,
							message, sent);
					worker.execute(); 
				} catch (BadLocationException e1) {
					e1.printStackTrace();
				}
			}
		}
		
		
		public void removeUpdate(DocumentEvent e) {
			synchronized (area) {
				int changeLength = e.getLength();				
				currentVersion=client.getVersion();			
				int offset = e.getOffset();
				int endPosition = offset + changeLength;
				String message = "change " + documentName +" "+username+" " +currentVersion+" remove " + offset
						+ " " + endPosition;

				
				sent = true;
            	MessageSwingWorker worker = new MessageSwingWorker(client,
						message, sent);
				client.updateVersion(currentVersion+1);
				worker.execute();
			}
		}
	
		public void changedUpdate(DocumentEvent e) {
			
		}
	}


	
	
	private void manageCursor(int currentPos, int pivotPosition, int amount) {
		

		if (currentPos >= pivotPosition) {
			if (currentPos <= pivotPosition + Math.abs(amount)) {
				caret.setDot(pivotPosition);
			} else {
				caret.setDot(amount+currentPos);
			}
		}
		else{
			caret.setDot(currentPos);
		}
		
	}

	
	public void updateDocument(String updatedText, int editPosition,
			int editLength, String username, int version) {
		documentText = KodimiDekodimi.decode(updatedText);
		int pos = caret.getDot();
		synchronized (area) {
			if(this.username!=null && !this.username.equals(username)){
			area.getDocument().removeDocumentListener(documentListener);
			area.setText(documentText);
			area.getDocument().addDocumentListener(documentListener);
			manageCursor(pos, editPosition, editLength);
			}
			else if(this.username!=null && this.username.equals(username)) {
				
				if(currentVersion<version-1){
					area.getDocument().removeDocumentListener(documentListener);
					area.setText(documentText);
					area.getDocument().addDocumentListener(documentListener);
					caret.setDot(editPosition+editLength);
				}
				
			}

		}
	}
	
	private class NewFileListener implements ActionListener {
		
	
		public void actionPerformed(ActionEvent e) {
			String newDocumentName = JOptionPane.showInputDialog(
					"Shenoni emrin e dokumetit te ri", "");
			if (newDocumentName !=null){
			    String message = "new " + newDocumentName;
            	MessageSwingWorker worker = new MessageSwingWorker(client,
						message, true);
				worker.execute();
			}
		}
	}

	private class OpenFileListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			client.sendMessageToServer("look");
		}
	}
private class SaveFileListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			client.sendMessageToServer("save");
		}
	}
	
	private class ExitFileListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			int n = JOptionPane.showConfirmDialog(null,
					"Are you sure you want to quit?", "Exit",
					JOptionPane.YES_NO_OPTION);
			if (n == 0) {
				if(!client.getSocket().isClosed()) {
					client.sendMessageToServer("bye");
					}
				System.exit(0);
			}
		}
	}
	private class CopyListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			area.copy();
		}
	}
	private class PasteListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			area.paste();
		}
	}
	
	private class CutListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			area.cut();
		}
	}
        public class MessageSwingWorker extends SwingWorker<Void, Void>{
	private Client client;
	private String message;
	private boolean sent;
	
	
	public MessageSwingWorker(Client client, String message, boolean sent){
		this.client = client;
		this.message = message;
		this.sent = sent;
	}
	
	
	protected Void doInBackground() {
		client.sendMessageToServer(message);
		done();
		return null;
	}
	
	
	protected void done() {
		client.getMainWindow().repaint();
		sent = false;
		
	}
	

}

}
