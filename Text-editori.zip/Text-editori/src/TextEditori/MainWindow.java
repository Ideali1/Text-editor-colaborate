package TextEditori;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.ArrayList;
import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;


import client.Client;




public class MainWindow extends JFrame {

	
	private static final long serialVersionUID = 1L;
	private WelcomeView welcomeView;
	private DocumentView documentView;
	private ConnectView connectView;
	private OpenDocumentDialog openDocumentDialog;
	private ArrayList<String> documentNames;
	private Client client;
	private String username;

	
	public MainWindow() {
		setTitle("Collaborative Text Editor");
		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setPreferredSize(new Dimension(275, 180));
		connectView = new ConnectView(this);
		add(connectView, BorderLayout.CENTER);
		pack();
	}

	
	public void switchToWelcomeView() {
		setVisible(false);
		getContentPane().remove(connectView);

		setPreferredSize(new Dimension(350, 100));
		setMinimumSize(new Dimension(350, 100));
		setMaximumSize(new Dimension(350, 100));
		welcomeView = new WelcomeView(this, client);
		add(welcomeView, BorderLayout.CENTER);

		
		setVisible(true);
	}

	
	public void openUsernameDialog() {
		String username = JOptionPane.showInputDialog("Shenoni emrin tuaj", "");
		if(username==null){
			JOptionPane.showMessageDialog(null, "Ju lutem mos e leni hapsiren e zbrazet", "Error",
					JOptionPane.ERROR_MESSAGE);
		}
		else{
		client.sendMessageToServer("name " + username);
		}
	}
	
	public void setUsername(String name){
		this.username = name;
	}
	
	public String getUsername(){
		return username;
	}

	
	public void switchToDocumentView(String documentName, String documentText) {
		setVisible(false);
		removeAllViews();
		setPreferredSize(new Dimension(600, 500));
		setMinimumSize(new Dimension(600, 500));
		setMaximumSize(new Dimension(600, 500));
		documentView = new DocumentView(this, documentName, documentText);
		this.addWindowListener(new ExitWindowListener(client));
		getContentPane().add(documentView, BorderLayout.CENTER);
		getContentPane().validate();
		getContentPane().repaint();
		setVisible(true);
		
	}

	
	private void removeAllViews() {
		if (welcomeView != null) {
			getContentPane().remove(welcomeView);
		}
		if (connectView != null) {
			getContentPane().remove(connectView);
		}
		if (documentView != null) {
			getContentPane().remove(documentView);
		}
	}


	public void displayOpenDocuments(ArrayList<String> documentNames) {
		
		openDocumentDialog = new OpenDocumentDialog(documentNames, client);
	}

	public void updateDocument(String documentText, int editPosition,
			int editLength, String username, int version) {
		
		if (documentView != null) {
			documentView.updateDocument(documentText, editPosition, editLength,
					username, version);
			getContentPane().repaint();
		}

	}

	
	public void openVersionErrorView(String error) {
		int n = JOptionPane.showConfirmDialog(null, error, "Error",
				JOptionPane.ERROR_MESSAGE);
		client.sendMessageToServer("open " + client.getDocumentName());
		
	}


	public void openErrorView(String error) {
		JOptionPane.showMessageDialog(null, error, "Error",
				JOptionPane.ERROR_MESSAGE);
	}

	public void setClient(Client client) {
		this.client = client;
	}

	
	public Client getClient() {
		return client;
	}

        public class ConnectView extends JPanel implements ActionListener {

	private final MainWindow frame;

	private final JLabel serverAddressLabel;
	private final JLabel hostLabel;
	private final JTextField host;
	private final JLabel portLabel;
	private final JTextField port;
	private final JButton connectButton;
	private Client client;
	


	public ConnectView(MainWindow frame) {
		this.frame = frame;
		serverAddressLabel = new JLabel("Ju lutem shenoni ip address e serverit:");
		hostLabel = new JLabel("Hosti:");
		host = new JTextField();
		host.addActionListener(this);
		portLabel = new JLabel("Porti:");
		port = new JTextField();
		port.addActionListener(this);
		connectButton = new JButton("Konektohu");
		connectButton.addActionListener(this);
		this.client = frame.getClient();

		GroupLayout layout = new GroupLayout(this);
		setLayout(layout);
		layout.setAutoCreateContainerGaps(true);
		layout.setAutoCreateGaps(true);

		layout.setHorizontalGroup(layout
				.createParallelGroup()
				.addComponent(serverAddressLabel)
				.addGroup(
						layout.createSequentialGroup()
								.addGroup(
										layout.createParallelGroup()
												.addComponent(hostLabel)
												.addComponent(portLabel))
								.addGroup(
										layout.createParallelGroup()
												.addComponent(host, 100, 150,
														Short.MAX_VALUE)
												.addComponent(port, 100, 150,
														Short.MAX_VALUE)))
				.addComponent(connectButton));
		layout.setVerticalGroup(layout
				.createSequentialGroup()
				.addComponent(serverAddressLabel)
				.addGroup(
						layout.createParallelGroup()
								.addComponent(hostLabel)
								.addComponent(host, GroupLayout.PREFERRED_SIZE,
										25, GroupLayout.PREFERRED_SIZE))
				.addGroup(
						layout.createParallelGroup()
								.addComponent(portLabel)
								.addComponent(port, GroupLayout.PREFERRED_SIZE,
										25, GroupLayout.PREFERRED_SIZE))
				.addComponent(connectButton));

	}


	public void actionPerformed(ActionEvent e) {
		String hostInput = host.getText().trim();
		String portInput = port.getText().trim();
		String portRegex = "\\d\\d?\\d?\\d?\\d?";
		if (hostInput.length() != 0 && portInput.matches(portRegex)) {
			try {
				client = new Client(Integer.parseInt(portInput), hostInput,
						frame);
				frame.setClient(client);
			} catch (NumberFormatException e1) {
				JOptionPane.showMessageDialog(null, "Invalid arguments",
						"Error", JOptionPane.ERROR_MESSAGE);

			}
			client.setMainWindow(frame);
			
			
			ConnectViewThread thread = new ConnectViewThread(this);
			
			thread.start();

		} else {
			JOptionPane.showMessageDialog(null, "Invalid arguments", "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	
	public Client getClient() {
		return client;
	}

public class ConnectViewThread extends Thread {
    private final ConnectView connectView;
    
    
	public ConnectViewThread(ConnectView connectView) {
		this.connectView=connectView;
	}


	public void run() {
		
		try {
			connectView.getClient().start();
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null,
				    e.getMessage(),
				    "Error",
				    JOptionPane.ERROR_MESSAGE);
		} catch (IllegalArgumentException e1){
			JOptionPane.showMessageDialog(null,
				    "Illegal arguments",
				    "Error",
				    JOptionPane.ERROR_MESSAGE);
			e1.printStackTrace();
		}
	}
}
}
        public class WelcomeView extends JPanel implements ActionListener {
	private final MainWindow frame;
	private JLabel welcomeLabel;
	private JLabel createNewLabel;
	private JTextField documentName;
	private JButton createNewButton, openDocumentButton;
	private Client client;

	
	public WelcomeView(MainWindow frame, Client client) {
		this.frame = frame;
		this.client = client;
		welcomeLabel = new JLabel("Collaborative Text Editor.");
		
		createNewLabel = new JLabel("Krijo nje dokument ose hape nje egzistues:");
		documentName = new JTextField();
		documentName.addActionListener(this);
		createNewButton = new JButton("Krijo dokumentin");
		createNewButton.addActionListener(this);
		
		openDocumentButton = new JButton("Hap Dokumentin ");
		openDocumentButton.addActionListener(this);

		GroupLayout layout = new GroupLayout(this);
		setLayout(layout);
		layout.setAutoCreateGaps(true);
		layout.setAutoCreateContainerGaps(true);

		layout.setHorizontalGroup(layout.createParallelGroup()
				.addComponent(welcomeLabel).addComponent(createNewLabel)
				
				.addGroup(layout.createSequentialGroup()
						.addComponent(createNewButton).addComponent(openDocumentButton))
				);
		layout.setVerticalGroup(layout
				.createSequentialGroup()
				.addComponent(welcomeLabel)
				.addComponent(createNewLabel)
				
				.addGroup(layout.createParallelGroup()
						.addComponent(createNewButton).addComponent(openDocumentButton)));

	}


	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == createNewButton || e.getSource() == documentName) {
			String newDocumentName = JOptionPane.showInputDialog("Shenoni emrin e dokumetit te ri");
			if (newDocumentName.matches("[\\w\\d]+")) {
				WelcomeViewThread thread = new WelcomeViewThread(client, "new "	+ newDocumentName);
				thread.start();
			} else {
				JOptionPane.showMessageDialog(null,
						"Ju lutem mos e leni hapsiren te pa plotesuar dhe mos perodrni shenja por vetem shkronja.",
						"Error", JOptionPane.ERROR_MESSAGE);
			}
		}
		else if (e.getSource() == openDocumentButton){
			client.sendMessageToServer("look");
		}
	}

	
	public Client getClient() {
		return client;

	}
        public class WelcomeViewThread extends Thread {


	private final String message;
	private final Client client;
	
  
	public WelcomeViewThread(Client client, String message) {

		this.message = message;
		this.client = client;
	}
    
	public void run() {
		
		client.sendMessageToServer(message);
	}

}
}
public class OpenDocumentDialog extends JOptionPane {
	private static final long serialVersionUID = 1L;

	
	public OpenDocumentDialog(ArrayList<String> documentNames, Client client) {

		
		if (documentNames == null) {
			JOptionPane.showMessageDialog(null,
					"There is no document on the server yet", "Error",
					JOptionPane.ERROR_MESSAGE);
		} 
		else {
			Object[] documentsOnServer = new Object[documentNames.size()];
			for (int i = 0; i < documentNames.size(); i++) {
				documentsOnServer[i] = documentNames.get(i);
			}
			String s = (String) JOptionPane.showInputDialog(null,
					"Choose a document:\n", "Open a document dialog",
					JOptionPane.PLAIN_MESSAGE, icon, documentsOnServer,
					documentsOnServer[0]);

			if (s != null) {
				client.sendMessageToServer("open " + s);
			}
		}
	}
}
public class ExitWindowListener implements WindowListener {
	private final Client client;
	
	
	public ExitWindowListener(Client client){
		this.client = client;
	}
	
	
	
	public void windowOpened(WindowEvent paramWindowEvent) {
		
	}



	public void windowClosing(WindowEvent paramWindowEvent) {
		
		if(client != null && !client.getSocket().isClosed()){
		client.sendMessageToServer("bye");
		System.exit(0);
		}
	}


	
	public void windowClosed(WindowEvent paramWindowEvent) {	
	}

	
	public void windowIconified(WindowEvent paramWindowEvent) {	
	}

	
	public void windowDeiconified(WindowEvent paramWindowEvent) {	
	}


	public void windowActivated(WindowEvent paramWindowEvent) {
	}

	
	public void windowDeactivated(WindowEvent paramWindowEvent) {
	}

}
}
